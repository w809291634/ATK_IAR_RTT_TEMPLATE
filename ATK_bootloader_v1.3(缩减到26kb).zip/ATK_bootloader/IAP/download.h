#ifndef __DOWNLOAD_H__
#define __DOWNLOAD_H__
#include "sys.h"

void IAP_download(void);
extern uint8_t download_part;
#endif
