#ifndef __LED_APP_H__
#define __LED_APP_H__

void led_thread_entry(void *param);

#endif